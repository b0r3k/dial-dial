# Soubor pro IBM Cloud Functions

V tomto souboru jsou koncentrované všechny metody porovnávací komponenty pro jednodušší nahrání do IBM Cloud Functions. Navíc obsahuje úpravu vstupu i výstupu potřebnou pro integraci do našeho systému.

Pro nahrání do IBM Cloud Functions vyžaduje ještě `virtualenv` s modulem `editdistance`. Toto `virtualenv` musí být spolu s tímto souborem zabaleno do `.zip`.